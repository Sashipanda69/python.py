import random

def Lets_game():
    choices = ["rock", "paper", "scissors"]
    user_score = 0
    computer_score = 0

    while True:
        print("\nRock-Paper-Scissors Game")
        print("*********************************")
        print("Enter your Weapon {rock, paper, scissors}: ")
        user_choice = input().lower()

        while user_choice not in choices:
            print("Invalid input. Follow instruction: ")
            user_choice = input().lower()

        computer_choice = random.choice(choices)
        print(f"\nComputer chose: {computer_choice}")

        if user_choice == computer_choice:
            print("It's a tie!")
        elif (user_choice == "rock" and computer_choice == "scissors") or \
             (user_choice == "scissors" and computer_choice == "paper") or \
             (user_choice == "paper" and computer_choice == "rock"):
            print("You win!")
            user_score += 1
        else:
            print("Computer wins!")
            computer_score += 1

        print(f"\nScore - You: {user_score}, Computer: {computer_score}")

        play_again = input("Do you want to play again? (yes/no): ")
        while play_again not in ["yes", "no"]:
            print("Invalid input. Please enter yes or no: ")
            play_again = input().lower()

        if play_again == "no":
            break

    print("\nThanks for playing!")
Lets_game()